function y = sphere(x)
    y = sumsqr(x(1,:));
end

% bounds [-100, 100]
% maximum evaluations 150,000
% optimal 0.0
