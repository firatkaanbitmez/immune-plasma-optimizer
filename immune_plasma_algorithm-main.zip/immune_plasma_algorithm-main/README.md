# immune_plasma_algorithm
Immune Plasma Algorithm (IPA) implementation
